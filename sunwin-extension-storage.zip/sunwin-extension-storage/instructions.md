# Bài toán: Xếp bài Mậu Binh sinh ra mọi cách hợp lệ

## Mô tả
Các file liên quan:
+ inject.js: handleMessageData để nhận data từ socket vs sendWebSocketMessage để gửi message lên server
+ websocket.js: giao tiếp với màn hình điều khiển
+ log_message.txt: thứ tự gameid, message nhận bài + message xếp bài
Viết code (ưu tiên Javascript) để tự động sinh ra **tất cả các cách xếp bài hợp lệ** cho một bộ bài Mậu Binh (13 lá bài). Đầu vào là mảng số nguyên, đầu ra là danh sách các cách xếp chi hợp lệ (mỗi chi ghi rõ lá bài + loại bài) để gửi lên bảng điều khiển để hiển thị các cách chọn.
+ Nhận cách xếp bài từ màn hình điều khiển để gửi message xếp bài
---

## Đầu vào

- Một mảng gồm 13 số nguyên, mỗi số từ 0 đến 51, đại diện cho từng lá bài, áp dụng quy tắc mapping:
    - `valueIndex = Math.floor(i / 4)` (i là số quân bài)
    - `suitIndex = i % 4`
    - value: `['A','2','3',...,'K'][valueIndex]`
    - suit: `['♠', '♣', '♦', '♥'][suitIndex]`
- **Ví dụ:**
    ```js
    [8, 10, 51, 29, 25, 40, 38, 22, 1, 49, 32, 34, 35]
    ```

---

## Yêu cầu

- Sinh ra **tất cả các cách chia 13 lá thành 3 chi**:
    - `chi1`: 5 lá
    - `chi2`: 5 lá
    - `chi3`: 3 lá
    - Không lá nào bị lặp lại.
- Với mỗi phương án xếp bài, cần **phân loại thế bài** của từng chi:
    - Thùng phá sảnh
    - Tứ quý
    - Cù lũ
    - Thùng
    - Sảnh
    - Xám
    - Thú
    - Đôi
    - Mậu thầu
- **Chỉ lấy các cách xếp hợp lệ:**  
  `chi1` phải mạnh hơn hoặc bằng `chi2`, `chi2` mạnh hơn hoặc bằng `chi3` (xếp theo thứ tự độ mạnh).
- Đầu ra là **danh sách các cách xếp bài hợp lệ**, mỗi cách là một object/array gồm:
    - `chi1: {cards: [..], loai: ".."}`
    - `chi2: {cards: [..], loai: ".."}`
    - `chi3: {cards: [..], loai: ".."}`

---

## Đầu ra mong muốn

```json
[
  {
    "chi1": { "cards": ["3♦", "3♥", "K♥", ...], "loai": "sảnh" },
    "chi2": { "cards": ["...", "...", ...], "loai": "thú" },
    "chi3": { "cards": ["...", "...", ...], "loai": "mậu thầu" }
  },
  {
    "chi1": { "cards": [...], "loai": ... },
    "chi2": { "cards": [...], "loai": ... },
    "chi3": { "cards": [...], "loai": ... }
  }
  // ...
]
```

---

## Ghi chú

- Không trùng lặp, không bỏ sót phương án hợp lệ nào.
- Có thể hạn chế kết quả (top N mạnh nhất) nếu số lượng tổ hợp quá lớn.
- Code kết quả trả về cần đầy đủ thông tin cho từng chi, sẵn sàng để xuất ra hoặc đánh giá thêm.

---

## Tóm tắt

- Input: mảng 13 số nguyên quân bài.
- Ouput: danh sách mọi cách chia hợp lệ 3 chi (5-5-3), từng chi ghi rõ lá bài + loại bài.
- Có thể d��ng để chơi/bổ trợ Mậu Binh, hỗ trợ AI tự sinh phương án xếp bài tối ưu.
