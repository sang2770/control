# uncompyle6 version 3.9.3
# Python bytecode version base 3.8.0 (3413)
# Decompiled from: Python 3.11.13 (main, Jun  3 2025, 18:38:25) [Clang 17.0.0 (clang-1700.0.13.3)]
# Embedded file name: binhquay_common.py
import os, webview, threading, time
from datetime import datetime
from tobbew import Tobbew
import botF12, util, w32, win32gui, win32con, json, aF12Single, random, xepbaibinh, uuid, socket, requests, traceback, sys
UI_HTML = "ui/quaybinh.html"
UI_HTML = os.path.abspath(UI_HTML)
TIME_JOIN = 500
API_GETLINK = "https://b52-9979.online/api/v1/mrduy/get-link?name="
API_CHECKIP = "https://b52-9979.online/api/v1/common/check-ip"
API_GET_XEP_BAI = "https://b52-9979.online/python"
API_CHECKKEY = "https://b52-9979.online/api/v1/mrneo/checkkey?key=binh_common"
PROJECT_NAME = "BINHQUAY_COMMON"
API_LOGIN = util.cfgR(PROJECT_NAME, "API_LOGIN")
TOKEN = util.cfgR(PROJECT_NAME, "TOKEN")
env_profile_id = [
 "",
 util.cfgR(PROJECT_NAME, "profile_id_guest1"),
 util.cfgR(PROJECT_NAME, "profile_id_guest2"),
 util.cfgR(PROJECT_NAME, "profile_id_guest3"),
 util.cfgR(PROJECT_NAME, "profile_id_guest4"),
 util.cfgR(PROJECT_NAME, "profile_id_guest5"),
 util.cfgR(PROJECT_NAME, "profile_id_guest6"),
 util.cfgR(PROJECT_NAME, "profile_id_guest7"),
 util.cfgR(PROJECT_NAME, "profile_id_guest8"),
 util.cfgR(PROJECT_NAME, "profile_id_guest9"),
 util.cfgR(PROJECT_NAME, "profile_id_guest10"),
 util.cfgR(PROJECT_NAME, "profile_id_guest11"),
 util.cfgR(PROJECT_NAME, "profile_id_guest12"),
 util.cfgR(PROJECT_NAME, "profile_id_guest13"),
 util.cfgR(PROJECT_NAME, "profile_id_guest14"),
 util.cfgR(PROJECT_NAME, "profile_id_guest15"),
 util.cfgR(PROJECT_NAME, "profile_id_guest16"),
 util.cfgR(PROJECT_NAME, "profile_id_guest17"),
 util.cfgR(PROJECT_NAME, "profile_id_guest18"),
 util.cfgR(PROJECT_NAME, "profile_id_guest19"),
 util.cfgR(PROJECT_NAME, "profile_id_guest20")]
API_MOST_LOGIN_OPEN = API_LOGIN + "/api/browser/openBrowser"
API_IXBROWSER_OPEN = API_LOGIN + "/api/v2/profile-open"

def write_log(e):
    exc_type, exc_value, exc_tb = sys.exc_info()
    last = traceback.extract_tb(exc_tb)[-1]
    print(f"❌ Lỗi: {e}")
    print(f"📌 File: {last.filename}")
    print(f"📌 Hàm: {last.name}")
    print(f"📌 Dòng: {last.lineno}")
    log_dir = "logs"
    os.makedirs(log_dir, exist_ok=True)
    log_file = os.path.join(log_dir, datetime.now().strftime("%Y-%m-%d") + ".log")
    with open(log_file, "a", encoding="utf-8") as f:
        f.write("\n======================================================================\n")
        f.write(f'⏰ {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}\n')
        f.write(traceback.format_exc())
        f.write("\n")


class b52_TLJoinRoom(aF12Single.AppF12Single):
    bot = None
    reloading = False
    _destroyed = False

    def __init__(self):
        self.bot = Game_controller(self)
        self.bot.app = self
        wvw = webview.create_window("Version 1.0.0", UI_HTML, width=820,
          height=350,
          js_api=self,
          text_select=True,
          resizable=True)
        wvw.events.loaded += self.uiOnLoaded
        wvw.events.closed += self.uiOnClosed
        self.wvw = self.bot.wvw = wvw
        util.log("#===== X8_TLJoinRoom STARTED =====#")


class Game_controller(botF12.BotF12):
    app = None

    def __init__(self, parent_app=None):
        self.app = parent_app
        self.detectWHTab()
        self.room_id = 0
        self.link = ""
        self.type_game = "hit"
        self.gold = 100
        self.room_id = 0
        self.cardCollect = []
        self.idxMain = []
        self.list_user_agent = Tobbew.list_user_agent()
        self.numProfile = 3
        self.cardKhach = []
        self.resetCardKhach()

    def __del__(self):
        self.quitAllWeb()
        util.log("#===== x8 END =====#")

    def checkKey(self):
        hostname = socket.gethostname()
        print("hostname: " + hostname)
        static_uuid = uuid.uuid5(uuid.NAMESPACE_DNS, hostname)
        print("uuid: " + str(static_uuid))
        linkCheckKey = API_CHECKKEY + "&uuid=" + str(static_uuid)
        status = requests.get(linkCheckKey)
        status = status.json()
        if status["status"] == "success":
            expire_date = status["data"]["expire_date"]
            if not expire_date is None:
                if expire_date == "" or expire_date == "None":
                    expire_str = "Vĩnh viễn"
            else:
                expire_str = expire_date
            js_str = f"\n            f12form.expire = '{expire_str}';\n        "
            self.app.uiJS(js_str)
            return True
        js_str = "\n          f12form.status = 'Access Deny'\n    "
        self.app.uiJS(js_str)
        return False

    def quitAllWeb(self):
        try:
            for i in range(self.numProfile):
                idx = int(i) + 1
                name = "HD_player_" + str(idx)
                win32gui.PostMessage(getattr(self, name)._w2_hwnd, win32con.WM_CLOSE, 0, 0)

        except Exception as e:
            try:
                print(e)
            finally:
                e = None
                del e

    def openProfiles(self, data):
        if self.checkKey() == False:
            return
        self.numProfile = data["numProfile"]
        self.type_game = data["type_game"]

        def initPlayer(idx):
            name = "HD_player_" + str(idx)
            if data["type_profile"] == "chrome":
                setattr(self, name, Player(self, name, idx, "", "", "", "", ""))
            else:
                if data["type_profile"] == "mostlogin":
                    payload = json.dumps({"profileId": (env_profile_id[idx])})
                    headers = {'Authorization':TOKEN, 
                     'Content-Type':"application/json"}
                    response = requests.request("POST", API_MOST_LOGIN_OPEN, headers=headers, data=payload)
                    prf = response.json()
                    debugger_address = prf["http"]
                    drive_path = prf["driverPath"]
                    setattr(self, name, Player(self, name, idx, "", env_profile_id[idx], debugger_address, drive_path, ""))
                else:
                    if data["type_profile"] == "ixbrowser":
                        payload = json.dumps({"profile_id": (int(env_profile_id[idx]))})
                        headers = {"Content-Type": "application/json"}
                        response = requests.request("POST", API_IXBROWSER_OPEN, headers=headers, data=payload)
                        prf = response.json()
                        debugger_address = prf["data"]["debugging_address"]
                        drive_path = prf["data"]["webdriver"]
                        setattr(self, name, Player(self, name, idx, "", env_profile_id[idx], debugger_address, drive_path, ""))

        for i in range(self.numProfile):
            idx = int(i) + 1
            initPlayer(idx)

    def detectWHTab(self):
        width, height = w32.getScreenSize()
        height = height - 50
        self.width_tab = width // 4
        self.height_tab = height // 3

    def handleSetMoney(self, data):
        self.gold = int(data["gold"])

    def handleSetNumProfile(self, data):
        self.numProfile = int(data["numProfile"])

    def handleVaoSanh(self):
        for i in range(self.numProfile):
            idx = int(i) + 1
            name = "HD_player_" + str(idx)
            getattr(self, name).vaoSanh()

    def appUILoadedHandle(self):
        self.app.uiJS("window.uiCallBE=pywebview.api.uiCallBE;")
        self.app.uiJS(" $('#profile_numbers').focus(); ")

    def handleSapBai(self, data):
        name = "HD_player_" + str(data["idx"])
        getattr(self, name).handleSapBai(data["card"])

    def handleReGetCard(self, data):
        print(data)

    def resetCardKhach(self):
        self.cardKhach = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 
         17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 
         30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 
         43, 44, 45, 46, 47, 48, 49, 50, 51]
        print("===> reset", str(self.cardKhach))

    def showCardKhach(self, card):
        result = xepbaibinh.XepBaiBinh(card)
        card = ",".join([str(elem) for i, elem in enumerate(card)])
        js_str = "\n          f12form.BEShowCardKhach('" + str(card) + "','" + str(json.dumps(result.getData())) + "')"
        print(js_str)
        self.app.uiJS(js_str)

    def showCard(self, card, idx):
        result = xepbaibinh.XepBaiBinh(card)
        self.cardKhach = [x for x in self.cardKhach if x not in card]
        print(len(self.cardKhach), self.cardKhach)
        if len(self.cardKhach) == 13:
            self.showCardKhach(self.cardKhach)
        cardStr = ",".join([str(elem) for i, elem in enumerate(card)])
        js_str = "\n          f12form.BEShowCard('" + str(cardStr) + "','" + str(idx) + "', '" + str(json.dumps(result.getData())) + "')"
        print(js_str)
        self.app.uiJS(js_str)


class Player:

    def __init__(self, parent_app=None, nameWeb="", idx=0, proxy="", profile_id="", debugger_address="", drive_path="", user_agent={}):
        self.appBot = parent_app
        self.nameWeb = nameWeb
        self.run = False
        self.status = ""
        self.idx = str(idx)
        self.nameProfile = "initPlayer_" + self.idx
        self.displayName = ""
        self.card = []
        self.room_self = 0
        self.proxy = proxy
        self.profile_id = profile_id
        self.debugger_address = debugger_address
        self.drive_path = drive_path
        self.uid = ""
        self.user_agent = user_agent
        self.is_create = False
        self.is_scan = False
        self.is_find = False
        self.room_rejoin = 0
        self.totalInRoom = 0
        self.is_cancelled = False
        threading.Thread(target=(self._initWeb), args=(), daemon=True).start()

    def _initWeb(self):
        if self.profile_id == "":
            dev_prof = {'browser':"chrome",  'headless':0, 
             'user-agent':"", 
             'cors':1, 
             'loggingPrefs':1, 
             'proxyV2':self.proxy}
        else:
            dev_prof = {'browser':"mostlogin",  'profile_id':self.profile_id, 
             'remote_debugging_address':self.debugger_address, 
             'driver_path':self.drive_path}
        self.w = Tobbew({**dev_prof, **{"name": (self.nameProfile)}})
        link = requests.get(API_GETLINK + self.appBot.type_game)
        link = link.json()
        link = link["data"]["link"]
        self.appBot.link = link
        self.w.set_viewport_size(600, 400)
        self.w.open_url(link)
        title = self.nameProfile
        self.w._js("document.title ='" + title + "'")
        time.sleep(1)
        hwnd = self.findHwnd(title)
        self._w2_hwnd = hwnd
        if hwnd != 0:
            print("Load Profile " + str(self.idx) + " Done")
        self.initSocket()
        self.initJS()
        threading.Thread(target=(self.listenTab), args=(), daemon=True).start()

    def listenTab(self):
        self.w._js("localStorage.removeItem('action')")
        while True:
            strExcute = self.w._js("return localStorage.getItem('action')")
            if strExcute:
                parts = strExcute.split("-")
                action = parts[0] if len(parts) > 0 else None
                room_id = parts[1] if len(parts) > 1 else "0"
                if action == "createRoom":
                    self.createRoom()
                else:
                    if action == "cancelCreate":
                        self.cancelCreateRoom()
                    else:
                        if action == "joinRoom":
                            self.joinRoom(room_id)
                        else:
                            if action == "outRoom":
                                self.outRoom()
                            else:
                                if action == "createRejoin":
                                    self.room_rejoin = room_id
                                else:
                                    if action == "cancelRejoin":
                                        self.room_rejoin = 0
                                    else:
                                        if action == "scanRoom":
                                            self.scanRoom()
                                        else:
                                            if action == "cancelScan":
                                                self.cancelScanRoom()
                self.w._js("localStorage.removeItem('action')")
            else:
                time.sleep(0.8)

    def initSocket(self):

        def __skErr():
            return

        self.w.startListenSocket(self._Player__readSocket, _Player__skErr)

    def findHwnd(self, substring: str):
        hwnd_result = None

        def enum_handler(hwnd, _):
            nonlocal hwnd_result
            if hwnd_result:
                return
            if win32gui.IsWindowVisible(hwnd):
                title = win32gui.GetWindowText(hwnd)
                if substring.lower() in title.lower():
                    hwnd_result = hwnd

        win32gui.EnumWindows(enum_handler, None)
        return hwnd_result

    def initJS(self):
        tmp = '\n      if (!document.getElementById("roomBox")) {\n          document.body.insertAdjacentHTML(\'beforeend\', `\n                <div id="roomBox" style="\n                  font-family: system-ui;\n                  border: 1px solid #ccc;\n                  border-radius: 8px;\n                  padding: 4px;\n                  display: inline-flex;\n                  align-items: center;\n                  gap: 6px;\n                  background: #fff;\n                  position: absolute;\n                  top: 10px;\n                  right: 20px;\n                  z-index: 9999;\n                ">\n                  <button id="btn_scan" style="padding:4px 8px;border:none;border-radius:4px;background:#007bff;color:#fff;">Dò</button>\n                  <button id="btn_rejoin" style="padding:4px 8px;border:none;border-radius:4px;background:#28a745;color:#fff;">Vào lại</button>\n                  <span style="color:red;font-size: 16px;">G' + self.idx + '</span>\n                  <input id="room_id" type="text" placeholder="room_id" \n                        style="padding:4px 6px;border:1px solid #aaa;border-radius:4px;width:100px;">\n                  <button id="btn_create" style="padding:4px 8px;border:none;border-radius:4px;background:#007bff;color:#fff;">Tạo</button>\n                  <button id="btn_join" style="padding:4px 8px;border:none;border-radius:4px;background:#28a745;color:#fff;">Vào</button>\n                  <button id="btn_exit" style="padding:4px 8px;border:none;border-radius:4px;background:#dc3545;color:#fff;">Thoát</button>\n                </div>\n              `);\n      }\n\n      const roomInput = document.getElementById("room_id");\n      const btnCreate = document.getElementById("btn_create");\n      const btnJoin = document.getElementById("btn_join");\n      const btnExit = document.getElementById("btn_exit");\n      const btnRejoin = document.getElementById("btn_rejoin");\n      const btnScan = document.getElementById("btn_scan");\n      function saveToLocal(key, value) {\n          localStorage.removeItem(key);\n          localStorage.setItem(key, value);\n      }\n      \n      btnCreate.onclick = () => {\n          const roomId = roomInput.value.trim();\n          if (btnCreate.textContent === "Tạo") {\n              saveToLocal("action", "createRoom");\n              btnCreate.textContent = "Hủy";\n              btnCreate.style.background = "#6c757d";\n          } else {\n              saveToLocal("action", "cancelCreate");\n              btnCreate.textContent = "Tạo";\n              btnCreate.style.background = "#007bff";\n          }\n      };\n      btnScan.onclick = () => {\n          if (btnScan.textContent === "Dò") {\n              saveToLocal("action", "scanRoom");\n              btnScan.textContent = "Stop";\n              btnScan.style.background = "#6c757d";\n          } else {\n              saveToLocal("action", "cancelScan");\n              btnScan.textContent = "Dò";\n              btnScan.style.background = "#007bff";\n          }\n      };\n      btnJoin.onclick = () => {\n          const roomId = roomInput.value.trim();\n          saveToLocal("action", \'joinRoom-\' + roomId);\n      };\n\n      btnExit.onclick = () => {\n          saveToLocal("action", "outRoom");\n      };\n      btnRejoin.onclick = () => {\n        const roomId = roomInput.value.trim();\n        if (btnRejoin.textContent === "Vào lại") {\n            saveToLocal("action", "createRejoin-" + roomId);\n            btnRejoin.textContent = "Hủy vào";\n            btnRejoin.style.background = "#6c757d";\n        } else {\n            saveToLocal("action", "cancelRejoin");\n            btnRejoin.textContent = "Vào lại";\n            btnRejoin.style.background = "#28a745";\n        }\n      };\n      __require(\'WSCardGameHandle\').default.getInstance().receiveLogout = function (t) {\n          console.log(\'K logout\')\n      }\n    '
        self.w._js(tmp)

    def __readSocketParse error at or near `SETUP_FINALLY' instruction at offset 0_2

    def resetFlag(self):
        self.is_create = False
        self.is_cancelled = False
        self.is_scan = False
        self.is_find = False

    def findRoom(self):
        if self.appBot.type_game in ('b52', 'rikvip'):
            tmp = 135
            if str(self.appBot.gold) == "100":
                tmp = 135
            else:
                if str(self.appBot.gold) == "500":
                    tmp = 136
                else:
                    if str(self.appBot.gold) == "1000":
                        tmp = 137
                    else:
                        if str(self.appBot.gold) == "2000":
                            tmp = 138
                        else:
                            if str(self.appBot.gold) == "5000":
                                tmp = 139
                            else:
                                if str(self.appBot.gold) == "10000":
                                    tmp = 140
                                else:
                                    if str(self.appBot.gold) == "20000":
                                        tmp = 141
                                    else:
                                        if str(self.appBot.gold) == "50000":
                                            tmp = 142
                                        else:
                                            if str(self.appBot.gold) == "100000":
                                                tmp = 143
            self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " tạo phòng'")
            jsCall = '\n        __require(\'GamePlayManager\').default.getInstance().sendData(\'[3,"Simms",' + str(tmp) + ',""]\');\n        '
            self.w._js(jsCall)
            return
        if self.is_cancelled == True:
            self.resetFlag()
            return
        self.is_find = True
        self.w._js('\n      const btnCreate = document.getElementById("btn_create");\n      const btnScan = document.getElementById("btn_scan");\n\n      btnCreate.textContent = "Tạo";\n      btnCreate.style.background = "#007bff";\n      btnScan.textContent = "Dò";\n      btnScan.style.background = "#007bff";\n     ')
        self.bookRoom()
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " cướp phòng'")

    def scanRoom(self):
        if self.is_cancelled == True:
            self.resetFlag()
            return
        self.is_scan = True
        self.is_create = False
        self.w._js('\n      const btnCreate = document.getElementById("btn_create");\n      const btnScan = document.getElementById("btn_scan");\n\n      btnCreate.textContent = "Tạo";\n      btnCreate.style.background = "#007bff";\n\n     ')
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " dò phòng'")
        self.bookRoom()

    def cancelScanRoom(self):
        self.is_cancelled = True
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " hủy dò phòng'")
        self.is_scan = False

    def createRoom(self):
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " tạo phòng'")
        self.is_create = True
        self.is_scan = False
        self.w._js('\n      const btnCreate = document.getElementById("btn_create");\n      const btnScan = document.getElementById("btn_scan");\n    \n      btnScan.textContent = "Dò";\n      btnScan.style.background = "#007bff";\n\n    ')
        if self.appBot.type_game in ('b52', 'rikvip'):
            self.w._js("__require('GamePlayManager').default.getInstance().requestcreateRoom(4, " + str(self.appBot.gold) + ", 4)")
            return
        if self.appBot.type_game in ('w79', 'vip79', 'kclub'):
            self.w._js('\n        System.get(\'chunks:///_virtual/CardGameCommonRequest.ts\').default.getInstance().sendData(\'[6,"Simms","channelPlugin",{"cmd":308,"gid":4,"b":' + str(self.appBot.gold) + ',"Mu":4,"pwd":"", aid:"1",iJ: true, inc: true}]\');\n        ')
            return
        if self.is_cancelled == True:
            self.resetFlag()
            return
        tmp = 53
        if str(self.appBot.gold) == "100":
            tmp = 53
        else:
            if str(self.appBot.gold) == "500":
                tmp = 54
            else:
                if str(self.appBot.gold) == "1000":
                    tmp = 55
                else:
                    if str(self.appBot.gold) == "2000":
                        tmp = 56
                    else:
                        if str(self.appBot.gold) == "5000":
                            tmp = 57
                        else:
                            if str(self.appBot.gold) == "10000":
                                tmp = 58
                            else:
                                if str(self.appBot.gold) == "20000":
                                    tmp = 59
                                else:
                                    if str(self.appBot.gold) == "50000":
                                        tmp = 60
                                    else:
                                        if str(self.appBot.gold) == "100000":
                                            tmp = 61
                                        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " tạo phòng'")
                                        jsCall = '\n    __require(\'GamePlayManager\').default.getInstance().sendData(\'[3,"Simms",' + str(tmp) + ',""]\');\n    '
                                        self.w._js(jsCall)

    def bookRoom(self):
        jsCall = '\n    __require(\'GamePlayManager\').default.getInstance().sendData(\'[6, "Simms", "channelPlugin", {cmd:313, gid: 4, aid:1, b:' + str(self.appBot.gold) + "}]');\n    "
        self.w._js(jsCall)
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " dò phòng'")

    def cancelCreateRoom(self):
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " hủy tạo phòng'")
        self.is_cancelled = True
        self.is_create = False

    def outRoom(self):
        self.w._js("__require('GameController').default.prototype.sendLeaveRoom();")

    def joinRoom(self, room_id=0):
        if room_id:
            if room_id.isdigit():
                if int(room_id) > 0:
                    self.appBot.room_id = int(room_id)
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " vào lại'")
        if self.appBot.type_game in ('b52', 'rikvip'):
            self.w._js("__require('GamePlayManager').default.getInstance().joinRoom(" + str(self.appBot.room_id) + ", 0, '', true);")
            return
        if self.appBot.type_game in ('w79', 'vip79', 'kclub'):
            self.w._js('\n          System.get(\'chunks:///_virtual/WSCardGameHandle.ts\').default.getInstance().ws.sendData(\'[3,"Simms",' + str(self.appBot.room_id) + ',"", true]\');\n          ')
            return
        jsCall = '\n      __require(\'GamePlayManager\').default.getInstance().sendData(\'[8,"Simms",' + str(self.appBot.room_id) + ', "", 4]\');\n      '
        self.w._js(jsCall)

    def stillRoom(self):
        self.appBot.app.uiJS("f12form.status = '" + str(self.idx) + " giữ phòng'")
        jsCall = '\n      __require(\'GamePlayManager\').default.getInstance().sendData(\'[8,"Simms",' + str(self.room_id) + ', "", 4]\');\n      '
        self.w._js(jsCall)

    def getCurrentLink(self):
        return self.w._driver.current_url

    def vaoSanh(self):
        self.initJS()
        if self.appBot.type_game in ('w79', 'vip79', 'kclub'):
            jsCall = "System.get('chunks:///_virtual/Lobby.ts').Lobby.prototype.openSceneGame('MauBinh', function(){});"
        else:
            if self.appBot.type_game == "iwin":
                jsCall = 'System.get(\'chunks:///_virtual/LobbyViewController.ts\').default.Instance.onClickIConGame(null,"vgcg_4");'
            else:
                if self.appBot.type_game == "gem":
                    jsCall = "System.get('chunks:///_virtual/FullScreenGameItemView.ts').FullScreenGameItemView.clickGame(4);"
                else:
                    if self.appBot.type_game == "man":
                        jsCall = "System.get('chunks:///_virtual/FullScreenGameItemView.ts').FullScreenGameItemView.clickGame(4);"
                    else:
                        jsCall = '__require(\'LobbyViewController\').default.Instance.onClickIConGame(null,"vgcg_4");'
        self.w._js(jsCall)

    def showAnDanh(self):
        if self.appBot.type_game == "gem":
            self.w._js('\n               cc.find("Canvas").getChildByName("downloading_node").getChildByName("game_node").getChildByName("game").getChildByName("fullScreenGameNode").getChildByName("prefab_binh")._components[1].setRoomIncognito(false);                \n           ')
        else:
            if self.appBot.type_game == "man":
                self.w._js('\n              cc.find("Canvas").getChildByName("downloading_node").getChildByName("game_node").getChildByName("game").getChildByName("fullScreenGameNode").getChildByName("prefab_binh")._components[1].setRoomIncognito(false);                \n          ')
            else:
                if self.appBot.type_game == "iwin":
                    self.w._js("\n          cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mainGameController.players.forEach(el=>{\n              el.showAnDanhWhenDone()\n          });\n          cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mainGameController._soVanKhongThaoTac = 0;\n          cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mainGameController._khongThaoTac = false;\n          ")
                else:
                    if self.appBot.type_game in ('w79', 'vip79', 'kclub'):
                        self.w._js("cc.find('Canvas').getChildByName('MainUiNode').getChildByName('MauBinh')._components[2].players.forEach(el=>{\n              el.showAnDanhWhenDone();\n          })")
                    else:
                        self.w._js("\n              cc.find('Canvas')._children[1]._children[0]._components[0].players.forEach(el=>{\n                  el.showAnDanhWhenDone();\n              });\n              cc.find('Canvas')._children[1]._children[0]._components[0]._khongThaoTac = false;\n              cc.find('Canvas')._children[1]._children[0]._components[0]._soVanKhongThaoTac = 0;\n              __require('GameController').default.prototype.checkVuotSoVan = function(){\n                  console.log('k bi moi')\n              }\n              __require('MauBinhController').default.prototype.checkVuotSoVan = function(){\n                  console.log('k bi moi');\n              }  \n          ")

    def stopAllAction(self):
        self.is_create = False
        self.is_scan = False
        self.is_find = False
        self.w._js('\n      const btnCreate = document.getElementById("btn_create");\n      const btnScan = document.getElementById("btn_scan");\n\n      btnCreate.textContent = "Tạo";\n      btnCreate.style.background = "#007bff";\n      btnScan.textContent = "Dò";\n      btnScan.style.background = "#007bff";\n\n     ')

    def _getPlayerName(self):
        return self.w._js("return __require('GamePlayManager').default.getInstance().displayName;")

    def handleSapBai(self, card):
        print(self._getPlayerName(), "xep bai", card, self.appBot.type_game)
        i = 12
        if self.appBot.type_game == "gem" or self.appBot.type_game == "man":
            for index, value in enumerate(card):
                jsCall = '\n                cc.find("Canvas").getChildByName("downloading_node").getChildByName("game_node").getChildByName("game").getChildByName("fullScreenGameNode").getChildByName("prefab_binh")._components[1].setTextureWithCode(\n                    cc.find("Canvas").getChildByName("downloading_node").getChildByName("game_node").getChildByName("game").getChildByName("fullScreenGameNode").getChildByName("prefab_binh")._components[1]._thisPlayerCards[' + str(i) + "],\n                    " + str(value) + "\n                )\n            "
                self.w._js(jsCall)
                time.sleep(0.05)
                i = i - 1
            else:
                getattr(self, self.nameWeb)._js('cc.find("Canvas").getChildByName("downloading_node").getChildByName("game_node").getChildByName("game").getChildByName("fullScreenGameNode").getChildByName("prefab_binh")._components[1].updateTextBinh();')
                return

        if self.appBot.type_game == "iwin":
            for index, value in enumerate(card):
                if self.appBot.type_game == "iwin":
                    jsCall = "    \n                    cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mainGameController.AllPlayers['" + self.uid + "'].cards[" + str(i) + "].setTextureWithCode(" + str(value) + ", 4);\n                "
                self.w._js(jsCall)
                time.sleep(0.05)
                i = i - 1
            else:
                self.w._js("\n          cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mauBinhController.updateTextBinh();\n          cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mainGameController._soVanKhongThaoTac = 0;\n          cc.find('Canvas')._children[1]._children[0]._components[0].mainGameViewModel.mainGameController._khongThaoTac = false;        \n        ")
                return

        if self.appBot.type_game in ('w79', 'vip79', 'kclub'):
            jsCall = ""
            for index, c in enumerate(card):
                jsCall += "cc.find('Canvas').getChildByName('MainUiNode').getChildByName('MauBinh')._components[2]._thisPlayerView.cards[" + str(i) + "].setTextureWithCode(" + str(c) + ", 4);"
                i = i - 1
            else:
                jsCall += "cc.find('Canvas').getChildByName('MainUiNode').getChildByName('MauBinh')._components[2].updateTextBinh()"
                self.w._js(jsCall)
                return

        for index, value in enumerate(card):
            jsCall = "    \n              cc.find('Canvas')._children[1]._children[0]._components[0].AllPlayers[__require('GamePlayManager').default.getInstance().userID].cards[" + str(i) + "].setTextureWithCode(" + str(value) + ", __require('GamePlayManager').default.getInstance().gameID);\n          "
            self.w._js(jsCall)
            time.sleep(0.05)
            i = i - 1
        else:
            self.w._js("\n        cc.find('Canvas')._children[1]._children[0]._components[0].updateTextBinh();\n        cc.find('Canvas')._children[1]._children[0]._components[0]._khongThaoTac = false;\n        cc.find('Canvas')._children[1]._children[0]._components[0]._soVanKhongThaoTac = 0;\n        __require('GameController').default.prototype.checkVuotSoVan = function(){\n            console.log('k bi moi')\n        }\n        __require('MauBinhController').default.prototype.checkVuotSoVan = function(){\n            console.log('k bi moi');\n        }\n      ")


if __name__ == "__main__":
    app = b52_TLJoinRoom()
    webview.start()
    app.bot.__del__()
    app.__del__()