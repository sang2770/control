const WS_URL = "ws://localhost:";
const LOG_PREFIX = "WS-Local:";
let websocket = null;

const log = (message, data) => {
  console.log(LOG_PREFIX, message, data || "");
};
console.log("Init Websocket");


const connectWebSocket = (onMessageCallback) => {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    log("WebSocket already connected");
    return websocket;
  }

  fetch(chrome.runtime.getURL("port.json"))
    .then((response) => response.json())
    .then((config) => {
      try {
        console.log("Port", config.port);

        // read port from config
        const port = config.port;
        websocket = new WebSocket(`${WS_URL}${port}`);

        websocket.onopen = () => {
          log("Connected to WebSocket server");
          chrome.runtime.sendMessage({ action: "websocketConnected" });
        };

        websocket.onclose = () => {
          log("Disconnected from WebSocket server");
          setTimeout(() => connectWebSocket(onMessageCallback), 5000);
        };

        websocket.onerror = (error) => {
          log("WebSocket error:", error);
        };

        websocket.onmessage = (event) => {
          const message = JSON.parse(event.data);
          log("WS Received:", message);
          onMessageCallback(message);
        };

        return websocket;
      } catch (error) {
        log("Error connecting to WebSocket:", error);
        setTimeout(() => connectWebSocket(onMessageCallback), 5000);
        return null;
      }
    });
};
const sendMessage = (action, data, dataKey) => {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    const message = {
      action: action,
      [dataKey]: data,
    };
    websocket.send(JSON.stringify(message));
    log(`Sent ${dataKey} to server:`, data);
    return true;
  } else {
    log(`Cannot send ${dataKey}: WebSocket not connected`);
    return false;
  }
};

const sendUserKey = (userKey) => {
  return sendMessage("updateSystemKey", userKey, "systemKey");
};

const sendUserStatus = (userStatus) => {
  return sendMessage("updateUserStatus", userStatus, "userStatus");
};

const checkWebSocketStatus = () => {
  return websocket && websocket.readyState === WebSocket.OPEN;
};

// Expose functions to content.js
window.websocket = {
  connect: connectWebSocket,
  sendUserKey: sendUserKey,
  checkStatus: checkWebSocketStatus,
  sendUserStatus: sendUserStatus,
};
