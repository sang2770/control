console.log("[MauBinh Monitor] Inline script START at:", new Date().toISOString());
(function () {
  // Hàm tạo console ẩn
  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error("[MauBinh Monitor] Lỗi tạo debug console:", e);
      return console.log.bind(console);
    }
  }

  const debug = createDebugConsole();
  window.phomMonitor = window.phomMonitor || {};
  window.phomMonitor.activeWebSocket = null;
  window.phomMonitor.currentUser = null; // Track current user info

  // Ghi đè WebSocket
  debug(
    "%c[MauBinh Monitor] Đang ghi đè WebSocket...",
    "color: orange; font-weight: bold;",
    new Date().toISOString()
  );
  const OriginalWebSocket = window.WebSocket;
  window.WebSocket = new Proxy(OriginalWebSocket, {
    construct(target, args) {
      const url = args[0];
      const ws = new target(...args);
      debug("[MauBinh Monitor] Tạo WebSocket:", url);
      if (!url.includes("ws-lby.azhkthg1.net") && !url.includes("ws-card04.azhkthg1.net")) {
        return ws;
      }
      debug("[MauBinh Monitor] Đã tạo WebSocket:", url, new Date().toISOString());

      debug(
        "%c[MauBinh Monitor] Kết nối WebSocket mới:",
        "color: green; font-weight: bold;",
        url
      );
      window.phomMonitor.activeWebSocket = ws;

      // Common decode function for both incoming and outgoing messages
      const decodeMessageData = (data, direction = "incoming") => {
        // Early validation checks
        if (data === null || data === undefined) {
          debug(`${direction.toUpperCase()} data is null/undefined`);
          return null;
        }

        try {
          // If data is already a string (outgoing), try JSON first
          if (typeof data === 'string') {
            if (data.trim() === '') {
              debug(`${direction.toUpperCase()} empty string`);
              return null;
            }
            try {
              const jsonData = JSON.parse(data);
              // debug(`${direction.toUpperCase()} JSON:`, jsonData);
              return jsonData;
            } catch (jsonError) {
              // debug(`${direction.toUpperCase()} STRING:`, data);
              return data;
            }
          }

          // If data is binary (incoming), validate and try MessagePack first
          let bytes;
          if (data instanceof ArrayBuffer) {
            if (data.byteLength === 0) {
              debug(`${direction.toUpperCase()} empty ArrayBuffer`);
              return null;
            }
            bytes = new Uint8Array(data);
          } else if (data instanceof Uint8Array) {
            if (data.length === 0) {
              debug(`${direction.toUpperCase()} empty Uint8Array`);
              return null;
            }
            bytes = data;
          } else if (data instanceof Blob) {
            debug(`${direction.toUpperCase()} Blob data, not supported yet`);
            return null;
          } else {
            // Try to convert other types to Uint8Array
            try {
              bytes = new Uint8Array(data);
              if (bytes.length === 0) {
                debug(`${direction.toUpperCase()} empty converted array`);
                return null;
              }
            } catch (conversionError) {
              debug(`${direction.toUpperCase()} failed to convert to Uint8Array:`, conversionError.message);
              return null;
            }
          }

          // Try MessagePack decode
          if (typeof MessagePack !== 'undefined' && MessagePack.decode) {
            try {
              const decoded = MessagePack.decode(bytes);
              // debug(`${direction.toUpperCase()} MSGPACK:`, decoded);
              return decoded;
            } catch (msgpackError) {
              // debug(`MSGPACK DECODE ERROR:`, msgpackError.message);
            }
          }

          // Fallback to JSON decode
          try {
            const text = new TextDecoder().decode(bytes);
            if (text.trim()) {
              const jsonData = JSON.parse(text);
              // debug(`${direction.toUpperCase()} JSON FALLBACK:`, jsonData);
              return jsonData;
            } else {
              debug(`${direction.toUpperCase()} empty text after decode`);
              return null;
            }
          } catch (jsonError) {
            debug(`Raw binary data (${direction}):`, bytes);
          }

          return null;
        } catch (error) {
          debug(`DECODE ERROR (${direction}):`, error.message);
          return null;
        }
      };

      ws.addEventListener("open", () => {
        window.postMessage({ type: "MAUBINH_MONITOR_WS_READY" }, "*");
      });

      function handleMessageData(event) {
        try {
          const parsed = JSON.parse(event.data);

          let data = null;
          let cmd = null;

          if (Array.isArray(parsed)) {
            // Support both [5, data] and [5, "Simms", id, data]
            if (parsed[0] === 5) {
              if (parsed.length === 2) {
                data = parsed[1];
              } else if (parsed.length === 4) {
                data = parsed[3];
              }
            } else if (parsed[0] === 4) {
              debug("%c[MauBinh Monitor] Message cmd=4 (Leave):", "color: orange;", parsed);
              window.postMessage({ type: "MAUBINH_MONITOR_USER_LEAVE" }, "*");
              return;
            }
          }

          if (!data) return;
          cmd = data.cmd;

          // user moi vao ban
          if (cmd === 5) {
            debug("%c[MauBinh Monitor] User vào bàn:", "color: green;", data.dn);
            window.postMessage({
              type: "MAUBINH_MONITOR_USER_JOIN",
              data: {
                userName: data.dn,
                userUid: data.uid
              }
            });
          }

          // Thông tin user và gold
          if (cmd === 100) {
            const gold = data["As"]?.["gold"] ?? 0;
            const userKey = data["dn"];
            const userUid = data["uid"];

            window.phomMonitor.currentUser = {
              name: userKey,
              uid: userUid,
              gold: gold
            };

            window.postMessage({
              type: "MAUBINH_MONITOR_GOLD_UPDATE",
              data: {
                gold: gold ?? 0,
                userKey: userKey ?? "",
                userUid: userUid ?? ""
              },
            });
          }

          // Phân tích bài (cmd 600, 606, 850, 852)
          if ((cmd === 600 || cmd === 606 || cmd === 850 || cmd === 852) && data.cs) {
            debug(`%c[MauBinh Monitor] Nhận bài (cmd ${cmd}):`, "color: green;", data.cs);
            window.postMessage({
              type: "MAUBINH_MONITOR_INIT",
              data: { cnt: data.cs.length }
            });
            window.postMessage({
              type: "MAUBINH_MONITOR_MY_CARDS",
              data: { cards: data.cs }
            });
          }

          // Thông tin người chơi bàn
          if (cmd === 202) {
            debug("%c[MauBinh Monitor] Message cmd=202 (Room Info):", "color: orange;", data);
            window.postMessage({ type: "MAUBINH_MONITOR_ROOMDATA", roomData: data }, "*");
          }

          // Thông tin phòng
          if (cmd === 313 || cmd === 308) {
            const roomId = data.ri?.rid;
            if (roomId) {
              window.postMessage({ type: "MAUBINH_MONITOR_ROOMID", roomId: roomId }, "*");
            }
          }

          // Game end
          if (cmd === 205 && Array.isArray(data.ps)) {
            window.postMessage({ type: "MAUBINH_MONITOR_GAME_END" });
          }

          // Thông báo thao tác quá nhanh
          if (
            (typeof data === "string" && data.includes("Bạn thực hiện thao tác quá nhanh")) ||
            (data.mgs?.includes("Bạn thực hiện thao tác quá nhanh"))
          ) {
            alert("Bạn thực hiện thao tác quá nhanh. Vui lòng đợi...");
            window.postMessage({ type: "MAUBINH_MONITOR_MAX_ACTION" }, "*");
          }

          if (parsed.length === 5 && parsed[4] === "Phòng đầy") {
            window.postMessage({ type: "MAUBINH_MONITOR_USER_LEAVE" }, "*");
          }
        } catch (e) {
          debug("%c[MauBinh Monitor] Lỗi phân tích message:", "color: red;", e);
        }
      }
      ws.addEventListener("message", (event) => {
        const decodedData = decodeMessageData(event.data, "incoming");

        if (decodedData) {
          if (typeof decodedData === 'object' && Array.isArray(decodedData)) {
            const fakeEvent = { data: JSON.stringify(decodedData) };
            handleMessageData(fakeEvent);
          }
        }
      });

      const originalSend = ws.send;
      ws.send = function (data) {
        // debug("%c[MauBinh Monitor] Message gửi:", "color: purple;", data);
        // Decode outgoing message using common function
        const decodedData = decodeMessageData(data, "outgoing");
        debug("%c[MauBinh Monitor] Message gửi:", "color: purple;", decodedData);
        // Process decoded outgoing data
        if (decodedData && Array.isArray(decodedData)) {
          if (
            decodedData.length == 4 &&
            decodedData[0] === 6 &&
            decodedData[3]?.gid &&
            decodedData[3]?.cmd === 300
          ) {
            debug("%c[MauBinh Monitor] Vào game");
            window.postMessage(
              { type: "MAUBINH_MONITOR_GAME_ID", gameId: decodedData[3].gid },
              "*"
            );
            window.phomMonitor.gameId = decodedData[3].gid;
          }
          if (decodedData.length == 4 && decodedData[0] === 5 && decodedData[3]?.cmd === 5) {
            debug("%c[MauBinh Monitor] Đánh bài ID: ", "color: purple;", decodedData[2]);
            window.session_id = decodedData[2];
          }
        }
        let dataToSend = data;
        if (typeof data === 'object' && data !== null && !(data instanceof Uint8Array)) {
          try {
            if (typeof MessagePack !== 'undefined' && MessagePack.encode) {
              dataToSend = MessagePack.encode(data);
            } else {
              dataToSend = JSON.stringify(data);
            }
          } catch (error) {
            debug("%c[MauBinh Monitor] Encoding error, sending original data:", "color: red;", error);
            dataToSend = data;
          }
        }
        return originalSend.call(this, dataToSend);
      };

      return ws;
    },
  });

  debug(
    "%c[MauBinh Monitor] Đã ghi đè WebSocket.",
    "color: orange; font-weight: bold;",
    new Date().toISOString()
  );
  const sendWebSocketMessage = function (message, options = {}) {
    const {
      retryCount = 0,
      maxRetries = 10,
      retryInterval = 1000,
      actionName = "action",
      onSuccess,
    } = options;

    const ws = window.phomMonitor.activeWebSocket;
    if (!ws || ws.readyState !== WebSocket.OPEN) {
      debug(
        `%c[MauBinh Monitor] WebSocket not ready, retry ${retryCount + 1
        }/${maxRetries}`,
        "color: red;"
      );

      if (retryCount < maxRetries) {
        setTimeout(() => {
          sendWebSocketMessage(message, {
            ...options,
            retryCount: retryCount + 1,
          });
        }, retryInterval);
      } else {
        debug(
          `%c[MauBinh Monitor] Failed to send after ${maxRetries} retries.`,
          "color: red; font-weight: bold;"
        );
      }
      return;
    }

    // Handle array of messages - encode if needed
    debug(
      `%c[MauBinh Monitor] Sending ${actionName} message:`,
      "color: green;",
      message
    );

    // Encode message before sending
    let dataToSend;
    if (typeof message === 'object' && message !== null) {
      try {
        // Try MessagePack encoding first if available
        if (typeof MessagePack !== 'undefined' && MessagePack.encode) {
          dataToSend = MessagePack.encode(message);
          debug(`%c[MauBinh Monitor] Encoded ${actionName} with MessagePack`, "color: blue;");
        } else {
          // Fallback to JSON
          dataToSend = JSON.stringify(message);
          debug(`%c[MauBinh Monitor] Encoded ${actionName} with JSON`, "color: blue;");
        }
      } catch (error) {
        debug(`%c[MauBinh Monitor] Encoding error for ${actionName}:`, "color: red;", error);
        dataToSend = JSON.stringify(message); // Safe fallback
      }
    } else {
      dataToSend = message;
    }

    ws.send(dataToSend);

    if (onSuccess) {
      onSuccess();
    }
  };

  window.sendJoinMessage = function (selectedTable, retryCount = 0) {
    const message = [
      6,
      "Simms",
      "channelPlugin",
      { cmd: 313, gid: window.phomMonitor.gameId || 4, aid: 1, b: parseInt(selectedTable) },
    ];

    sendWebSocketMessage(message, {
      retryCount,
      actionName: "join table",
      onSuccess: () =>
        debug(
          "%c[MauBinh Monitor] Join message sent to table:",
          "color: green;",
          selectedTable
        ),
    });
  };

  window.sendLeaveMessage = function (roomId) {
    const messageOut = [4, "Simms", roomId];
    sendWebSocketMessage(messageOut, {
      maxRetries: 1,
      actionName: "leave room",
      onSuccess: () =>
        debug(
          "%c[MauBinh Monitor] Leave message sent for room:",
          "color: green;",
          roomId
        ),
    });
    const message2 = [6, "Simms", "channelPlugin", { cmd: 310 }];
    sendWebSocketMessage(message2, {
      maxRetries: 1,
      actionName: "leave room",
    });
  };

  window.createTableMessage = function (selectedTable) {
    const message = [
      6,
      "Simms",
      "channelPlugin",
      {
        cmd: 308,
        gid: window.phomMonitor.gameId || 4,
        aid: 1,
        b: parseInt(selectedTable),
        Mu: 4,
        pwd: "",
        iJ: false,
      },
    ];

    sendWebSocketMessage(message, {
      maxRetries: 1,
      actionName: "create table",
      onSuccess: () =>
        debug(
          "%c[MauBinh Monitor] Create table message sent:",
          "color: green;",
          selectedTable
        ),
    });
  };

  window.joinRoomByIdMessage = function (roomId) {
    const message = [3, "Simms", roomId, "1234"];

    sendWebSocketMessage(message, {
      maxRetries: 1,
      actionName: "join room by id",
      onSuccess: () =>
        debug(
          "%c[MauBinh Monitor] Join room by ID message sent:",
          "color: green;",
          roomId
        ),
    });
  };

  function setPlayerCards(values) {
    const comp = cc.find("Canvas/prefab_binh")
      ._components.find(c => c.setTextureWithCode);

    if (!comp) {
      debug("❌ Không tìm thấy component");
      return;
    }

    const cards = comp._thisPlayerCards;

    if (!cards || cards.length === 0) {
      debug("❌ Không có card");
      return;
    }

    values.forEach((value, i) => {
      if (!cards[i]) return;

      comp.setTextureWithCode(cards[i], value);
    });

    debug("✅ Đã set bài:", values);
  }

  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data.type === "MAUBINH_MONITOR_JOIN") {
      debug("%c[MauBinh Monitor] Message từ popup:", "color: orange;", event.data);
      const table = event.data.selectedTable || "100";
      if (window.sendJoinMessage) {
        window.sendJoinMessage(table);
      }
    } else if (event.data.type === "MAUBINH_MONITOR_LEAVE") {
      debug("%c[MauBinh Monitor] Message từ popup:", "color: orange;", event.data);
      const roomId = event.data.roomId || "";
      if (window.sendLeaveMessage) {
        window.sendLeaveMessage(roomId);
      }
    } else if (event.data.type === "MAUBINH_MONITOR_CREATE_TABLE") {
      debug("%c[MauBinh Monitor] Message từ popup:", "color: orange;", event.data);
      const table = event.data.selectedTable || "100";
      if (window.createTableMessage) {
        window.createTableMessage(table);
      }
    } else if (event.data.type === "MAUBINH_MONITOR_JOIN_ROOMID") {
      debug("%c[MauBinh Monitor] Message từ popup:", "color: orange;", event.data);
      const roomId = event.data.roomId || "";
      if (window.joinRoomByIdMessage && roomId) {
        window.joinRoomByIdMessage(roomId);
      }
    } else if (event.data.type === "MAUBINH_SET_ARRANGEMENT") {
      debug("%c[MauBinh Monitor] Setting Mau Binh arrangement:", "color: cyan;", event.data.data);
      const { cards } = event.data.data;
      setPlayerCards(cards);
    }
  });
})();
