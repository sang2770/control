console.log("Background script START at:", new Date().toISOString());
