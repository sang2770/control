(function () {
  // Constants
  const LOG_PREFIX = "[MauBinh Monitor]";

  // Global variables
  window.isJoiningLoop = false;
  window.isCreatingLoop = false;
  window.gold = 0;
  window.userKey = null;
  window.isPlaying = false;
  window.leaveRequested = false;

  window.joinTableTimeout = null;
  window.joinTableTimeoutCnt = 0;
  window.createTableTimeoutCnt = 0;
  window.checkTimeout = null;
  window.createTableInterval = null;
  window.gameId = null;
  window.roomPlayers = []; // Track players in current room
  window.knownSystemCards = {}; // Store cards for each system player in this game

  // Helper functions
  const log = (message, data) => {
    console.log(LOG_PREFIX, message, data || "");
  };

  const saveToStorage = (data, callback) => {
    chrome.storage.local.set(data, callback);
  };

  const saveSettings = ({
    joinDelay,
    checkDelay,
    selectedTable,
    systemKeys
  }) => {
    // Enforce 3000ms minimum
    joinDelay = Math.max(3000, parseInt(joinDelay) || 3000);
    checkDelay = Math.max(3000, parseInt(checkDelay) || 3000);
    saveToStorage({ joinDelay, checkDelay, selectedTable, systemKeys }, () => {
      log("Settings saved!", {
        joinDelay,
        checkDelay,
        selectedTable,
        systemKeys,
      });
      chrome.runtime.sendMessage({
        action: "settingsSaved",
        data: { joinDelay, checkDelay, selectedTable, systemKeys },
      });
    });
  };

  // Inject inline script
  function injectScript(name) {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL(name);
    script.onload = () => script.remove();
    (document.head || document.documentElement).appendChild(script);
    log("Injected inline script at:", name, new Date().toISOString());
  }

  // Inject msgpack library first, then the main inject script
  function injectScriptsSequentially() {
    const msgpackScript = document.createElement("script");
    msgpackScript.src = chrome.runtime.getURL("msgpack.min.js");
    msgpackScript.onload = () => {
      msgpackScript.remove();
      log("Injected msgpack library");
      // Inject main script after msgpack is loaded
      injectScript("inject.js");
    };
    (document.head || document.documentElement).appendChild(msgpackScript);
  }

  // Start injection
  injectScriptsSequentially();

  // Create debug console
  const debug = createDebugConsole();

  function createDebugConsole() {
    try {
      const iframe = document.createElement("iframe");
      iframe.style.display = "none";
      (document.body || document.documentElement).appendChild(iframe);
      return iframe.contentWindow.console.log.bind(
        iframe.contentWindow.console
      );
    } catch (e) {
      console.error(`${LOG_PREFIX} Lỗi tạo debug console:`, e);
      return () => { };
    }
  }

  // Handle room data
  function handleRoomData(roomData) {
    debug(
      `${LOG_PREFIX} Nhận được roomData: `, roomData
    )
    if (window.isPlaying) {
      debug(
        "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      return;
    }
    if (!window.isJoiningLoop && !window.isCreatingLoop) {
      debug(
        "%c[MauBinh Monitor] Quá trình vào bàn hoặc tạo bàn chưa bắt đầu hoặc đã dừng.",
        "color: orange;"
      );
      return;
    }
    chrome.storage.local.get(
      ["systemKeys", "checkDelay", "selectedTable"],
      ({ systemKeys = [], checkDelay = 3000, selectedTable = "100" }) => {
        // Update room players info and check for guest
        window.roomPlayers = roomData.ps || [];
        const players = window.roomPlayers;
        const systemPlayersInRoom = players.filter(p => systemKeys.includes(p.dn));

        debug(`${LOG_PREFIX} Room Info: ${players.length} players. Systems in room: ${systemPlayersInRoom.map(p => p.dn).join(", ")}`);

        if (systemPlayersInRoom.length === 3 && players.length === 4) {
          const guestPlayer = players.find(p => !systemKeys.includes(p.dn));
          if (guestPlayer) {
            debug(`${LOG_PREFIX} Found Guest Player: ${guestPlayer.dn}`);
          }
        }

        window.websocket.sendUserStatus({
          type: "MAUBINH_MONITOR_ROOMDATA",
          roomId: window.roomId || roomData.id,
          players: players,
          systemKeys: systemKeys
        });

        if (
          ![
            "100",
            "500",
            "1000",
            "2000",
            "5000",
            "10000",
            "20000",
            "50000",
            "100000",
            "200000",
            "500000",
            "1000000",
            "2000000",
            "5000000",
            "10000000",
          ].includes(selectedTable)
        ) {
          debug("%c[MauBinh Monitor] Bàn không hợp lệ.", "color: red;");
          return;
        }
        debug(
          `${LOG_PREFIX} Kiểm tra sau ${checkDelay}ms.`,
          new Date().toISOString()
        );

        window.checkTimeout = setTimeout(() => {
          if (window.isPlaying) {
            debug(
              "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
              "color: red;"
            );
            return;
          }
          if (shouldStayInRoom(roomData, systemKeys)) {
            debug("%c[MauBinh Monitor] Check: Ở lại bàn.", "color: orange;");
            window.websocket.sendUserStatus(
              window.userKey + "ở lại bàn. Dừng quá trình."
            );
          } else {
            debug("%c[MauBinh Monitor] Check: Rời bàn.", "color: orange;");
            leaveTable();
          }
        }, checkDelay);
      }
    );
  }

  function joinGame(callBack) {
    window.callBackAfterJoinGame = callBack;
    injectScript("autoJoinGame.js");
  }

  function shouldStayInRoom(roomData, systemKeys) {
    if (!Array.isArray(systemKeys)) return false;
    const userKey = window.userKey;
    const players = roomData.ps || [];
    const hostPlayer = players.find((p) => p.C === true);
    const hostKey = hostPlayer?.dn || null;
    const playerKeys = players.map((p) => p.dn);
    if (!playerKeys.includes(userKey)) return false;
    const hasSystemKey = playerKeys.some((key) =>
      systemKeys.includes(key) && key !== userKey
    );

    debug(`${LOG_PREFIX} Kiểm tra: ${players.length} người chơi, ${hasSystemKey ? "có" : "không có"} systemKey`, players)

    if (window.isCreatingLoop) {
      debug(`${LOG_PREFIX} Kiểm tra: ${userKey} === ${hostKey}`, userKey, hostKey)
      return userKey === hostKey;
    }
    return hasSystemKey;
  }

  function createTableWithSelectedTable(selectedTable) {
    const tryCreateTable = () => {
      debug(
        `${LOG_PREFIX} Tạo bàn với số tiền: ${selectedTable}`,
        new Date().toISOString()
      );
      const currentBet = config.createTable.range.default;
      const targetBet = parseInt(selectedTable);
      const listAvailableBet = [
        100, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000,
        1000000, 2000000, 5000000, 10000000,
      ];
      const currentIndex = listAvailableBet.indexOf(currentBet);
      if (!listAvailableBet.includes(targetBet) || currentIndex === -1) {
        debug("%c[MauBinh Monitor] Bàn không hợp lệ.", "color: red;");
        return;
      }
      window.postMessage(
        { type: "MAUBINH_MONITOR_CREATE_TABLE", selectedTable: targetBet },
        "*"
      );
    };

    tryCreateTable();

    window.createTableInterval = setInterval(() => {
      if (window.roomId) {
        debug(
          `${LOG_PREFIX} Tạo bàn thành công với số tiền: ${selectedTable}, roomId: ${window.roomId}`,
          new Date().toISOString()
        );
        clearInterval(window.createTableInterval);
        window.createTableInterval = null;
        return;
      } else {
        debug(
          `${LOG_PREFIX} Chưa có roomId, kiểm tra lại...`,
          new Date().toISOString()
        );
        window.createTableTimeoutCnt += 1;
        if (window.createTableTimeoutCnt > 3) {
          debug(
            "%c[MauBinh Monitor] Đã thử quá 3 lần, reload trang.",
            "color: red;"
          );
          clearInterval(window.createTableInterval);
          window.createTableInterval = null;
          window.location.reload();
          return;
        }
        tryCreateTable();
      }
    }, 2000);
  }



  function createTable(selectedTable) {
    window.isCreatingLoop = true;
    createTableWithSelectedTable(selectedTable);
  }

  function leaveTable() {
    if (window.isPlaying) {
      debug(
        "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      window.isJoiningLoop = false;
      window.isCreatingLoop = false;
      return;
    }

    if (window.roomId && !window.leaveRequested) {
      window.leaveRequested = true;
      debug("%c[MauBinh Monitor] LeaveTable - Rời bàn: " + window.roomId, "color: red;");
      injectScript("autoLeaveTable.js");
      return;
    } else {
      debug("%c[MauBinh Monitor] Không có roomId hoặc đã yêu cầu rời bàn.", "color: orange;");
      return;
    }
  }

  window.joinTable = function () {
    if (window.isPlaying) {
      debug(
        "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      window.isJoiningLoop = false;
      window.isCreatingLoop = false;
      window.isCreatingBotLoop = false;
      return;
    }
    chrome.storage.local.get(
      ["joinDelay", "selectedTable"],
      ({ joinDelay = 4000, selectedTable = "100" }) => {
        debug(
          `${LOG_PREFIX} Đã nhận được thông tin vào bàn: ${selectedTable}, số tiền: ${window.gold}`,
          new Date().toISOString()
        );
        if (window.gold < parseInt(selectedTable) * 10) {
          debug("%c[MauBinh Monitor] Không đủ số dư để vào bàn.", "color: red;");
          alert(
            "Không đủ số dư để vào bàn. Vui lòng nạp thêm tiền vào tài khoản."
          );
          window.isJoiningLoop = false;
          window.joinTableTimeout = null;
          window.isCreatingLoop = false;
          return;
        }
        function tryJoin() {
          if (!window.isJoiningLoop) {
            debug(
              "%c[MauBinh Monitor] Đã dừng quá trình vào bàn.",
              "color: orange;"
            );
            return;
          }
          if (window.roomId) {
            debug(
              "%c[MauBinh Monitor] Đã có roomId. Chờ thoát bàn",
              "color: orange;"
            );
            return;
          }

          if (window.joinTableTimeout) {
            debug(
              "%c[MauBinh Monitor] Quá trình vào bàn trước chưa hoàn tất",
              "color: orange;"
            );
            return;
          } else {
            window.postMessage(
              { type: "MAUBINH_MONITOR_JOIN", selectedTable },
              "*"
            );
          }

          window.joinTableTimeout = setTimeout(() => {
            if (!window.roomId) {
              debug(
                "%c[MauBinh Monitor] Không tìm thấy roomId. Thử lại sau " +
                joinDelay +
                "ms.",
                "color: orange;"
              );
              if (window.joinTableTimeoutCnt > 2) {
                debug(
                  "%c[MauBinh Monitor] Đã thử quá 2 lần, reload trang.",
                  "color: red;"
                );
                window.location.reload();
                return;
              }
              window.joinTableTimeoutCnt++;
              window.joinTableTimeout = null;
              setTimeout(tryJoin, joinDelay);
            }
          }, 3000);
        }
        if (!window.joinTableTimeout) {
          window.joinTableTimeoutCnt = 0;
        }
        setTimeout(tryJoin, joinDelay);
      }
    );
  };

  window.stopJoinTable = function () {
    debug("%c[MauBinh Monitor] Dừng", "color: orange;");
    if (window.isCreatingLoop) {
      debug("%c[MauBinh Monitor] Đã dừng quá trình tạo bàn.", "color: orange;");
    }
    if (window.isJoiningLoop) {
      debug("%c[MauBinh Monitor] Đã dừng quá trình vào bàn.", "color: orange;");
    }
    window.isCreatingLoop = false;
    window.isJoiningLoop = false;

    if (window.joinTableTimeout) {
      clearTimeout(window.joinTableTimeout);
      window.joinTableTimeout = null;
      window.joinTableTimeoutCnt = 0;
    }
    if (window.checkTimeout) {
      clearTimeout(window.checkTimeout);
      window.checkTimeout = null;
    }
    if (window.createTableInterval) {
      clearInterval(window.createTableInterval);
      window.createTableInterval = null;
    }
  };

  window.createTable = function () {
    chrome.storage.local.get(["selectedTable"], ({ selectedTable = "100" }) => {
      createTable(selectedTable);
    });
  };

  window.leaveTable = leaveTable;

  window.joinRoomById = function (roomId) {
    if (window.isPlaying) {
      debug(
        "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
        "color: red;"
      );
      return;
    }

    if (!roomId) {
      debug("%c[MauBinh Monitor] Không có roomId.", "color: red;");
      return;
    }

    const performJoin = () => {
      debug(`${LOG_PREFIX} Vào bàn theo ID: ${roomId}`, new Date().toISOString());
      window.postMessage({ type: "MAUBINH_MONITOR_JOIN_ROOMID", roomId }, "*");
    };

    if (window.roomId && window.roomId !== roomId) {
      debug(`${LOG_PREFIX} Đang ở bàn ${window.roomId}, thực hiện rời bàn trước khi vào bàn ${roomId}`);
      leaveTable();
      // Chờ 1.5s để đảm bảo lệnh rời bàn đã được xử lý bởi server trước khi vào bàn mới
      setTimeout(performJoin, 1500);
    } else {
      performJoin();
    }
  };

  // Load configuration and initialize WebSocket
  let config;
  fetch(chrome.runtime.getURL("config.json"))
    .then((response) => response.json())
    .then((data) => {
      config = data;
      // Initialize WebSocket with message handler
      window.websocket.connect((message) => {
        if (message.action === "saveSettings") {
          saveSettings(message);
        } else if (
          ["joinTable", "leaveTable", "createTable", "stopJoinTable", "stopCreateTable"].includes(
            message.action
          )
        ) {
          const actions = {
            joinTable: window.joinTable,
            stopJoinTable: window.stopJoinTable,
            createTable: window.createTable,
            leaveTable: window.leaveTable,
            stopCreateTable: window.stopJoinTable,
          };

          if (!window.gameId) {
            debug(
              "%c[MauBinh Monitor] Không có gameId. Vui lòng đăng nhập.",
              "color: red;"
            );
            joinGame(message.action);
            return true;
          }

          if (message.action === "leaveTable" || message.action === "stopCreateTable") {
            window.stopJoinTable();
          }

          if (message.action === "joinTable" && window.isJoiningLoop) {
            debug(
              "%c[MauBinh Monitor] Quá trình vào bàn đang chạy.",
              "color: orange;"
            );
            return;
          }

          if (message.action === "createTable" && window.isCreatingLoop) {
            debug(
              "%c[MauBinh Monitor] Quá trình vào bàn đang chạy.",
              "color: orange;"
            );
            return;
          }

          if (message.action === "joinTable") {
            window.isJoiningLoop = true;
          }
          if (window.isPlaying) {
            debug(
              "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
              "color: red;"
            );
            return;
          }
          if (message.action === "joinTable") {
            leaveTable();
            setTimeout(() => {
              actions[message.action]();
            }, 1500);
          } else {
            actions[message.action]();
          }
        } else if (message.action === "setMauBinhArrangement") {
          debug("%c[MauBinh Monitor] Received arrangement from server", "color: cyan;", message.data);
          // message.data should be the chi1, chi2, chi3 cardIds
          window.postMessage({
            type: "MAUBINH_SET_ARRANGEMENT",
            data: {
              ...message.data,
              roomId: window.roomId
            }
          }, "*");
        }
      });
    });

  // Handle window messages
  window.addEventListener("message", (event) => {
    if (event.source !== window) return;
    if (event.data.type === "MAUBINH_MONITOR_INIT") {
      window.isPlaying = true;
    } else if (event.data.type === "MAUBINH_MONITOR_ROOMDATA") {
      handleRoomData(event.data.roomData);
    } else if (event.data.type === "MAUBINH_MONITOR_GAME_END") {
      debug(
        "%c[MauBinh Monitor] Trò chơi kết thúc.",
        "color: orange;"
      )
      window.isPlaying = false;
      window.websocket.sendUserStatus({
        type: "MAUBINH_MONITOR_GAME_END",
        roomId: window.roomId
      });
    } else if (event.data.type === "MAUBINH_MONITOR_ROOMID") {
      if (window.roomId === event.data.roomId) {
        debug(
          "%c[MauBinh Monitor] Đã nhận được trùng roomId. Không thực hiện các tác vụ.",
          "color: orange;"
        );
        return;
      }
      if (window.roomId && event.data.roomId !== window.roomId) {
        debug(
          "%c[MauBinh Monitor] xung đột roomId. Rời bàn: " + window.roomId,
          "color: red;"
        );
        window.postMessage(
          { type: "MAUBINH_MONITOR_LEAVE", roomId: window.roomId },
          "*"
        );
      }
      if (window.joinTableTimeout) {
        clearTimeout(window.joinTableTimeout);
        window.joinTableTimeout = null;
        window.joinTableTimeoutCnt = 0;
      }
      const roomId = event.data.roomId;
      debug(`${LOG_PREFIX} Đã nhận roomId mới: ${roomId}`);
      window.roomId = roomId;
    } else if (event.data.type === "MAUBINH_MONITOR_MAX_ACTION") {
      debug(`${LOG_PREFIX} Thao tác quá nhanh. Dừng quá trình vào bàn.`);
      window.roomId = null;
      window.stopJoinTable();
      window.isPlaying = false;
      window.leaveRequested = false;
    } else if (event.data.type === "MAUBINH_MONITOR_GOLD_UPDATE") {
      window.gold = isNaN(Number(event.data.data.gold))
        ? 0
        : Number(event.data.data.gold);
      window.userKey = event.data.data.userKey;
      debug(
        `${LOG_PREFIX} Đã nhận số dư mới: ${window.gold}`,
        new Date().toISOString()
      );
      debug(
        `${LOG_PREFIX} Đã nhận userKey mới: ${window.userKey}`,
        new Date().toISOString()
      );
      if (window.userKey) {
        window.websocket.sendUserKey(window.userKey);
      }
    } else if (event.data.type === "MAUBINH_MONITOR_MY_CARDS") {
      window.isPlaying = true;
      const cards = event.data.data.cards;
      debug(`${LOG_PREFIX} Received cards to send to server for ${window.userKey || "me"}:`, cards);

      window.websocket.sendUserStatus({
        type: "MAUBINH_PLAYER_CARDS_REPORT",
        playerName: window.userKey,
        roomId: window.roomId,
        cards: cards
      });
    } else if (event.data.type === "MAUBINH_MONITOR_WS_READY") {
      debug(`${LOG_PREFIX} WebSocket đã sẵn sàng từ inject.js`);
    } else if (event.data.type === "MAUBINH_MONITOR_USER_LEAVE") {
      debug(
        "%c[MauBinh Monitor] Người chơi rời bàn." + window.roomId,
        "color: orange;"
      );
      window.isPlaying = false;
      window.roomId = null;
      window.leaveRequested = false;
      if (window.checkTimeout) {
        clearTimeout(window.checkTimeout);
        window.checkTimeout = null;
      }
      chrome.storage.local.get(["joinDelay"], ({ joinDelay = 4000 }) => {
        if (window.isCreatingLoop) {
          setTimeout(() => {
            debug(
              "%c[MauBinh Monitor] Thực hiện lại quá trình tạo bàn.",
              "color: orange;"
            );
            if (!window.isCreatingLoop) return;
            window.createTable();
          }, joinDelay);
        }
        if (window.isJoiningLoop) {
          setTimeout(() => {
            if (!window.isJoiningLoop) {
              debug(
                "%c[MauBinh Monitor] Đã dừng quá trình vào bàn.",
                "color: orange;"
              );
              return;
            }
            debug(
              "%c[MauBinh Monitor] Thực hiện lại quá trình vào bàn.",
              "color: orange;"
            );
            window.joinTable();
          }, joinDelay);
        }
      });
    } else if (event.data.type === "MAUBINH_MONITOR_GAME_ID") {
      debug(
        `${LOG_PREFIX} Đã nhận gameId mới: ${event.data.gameId}`,
        new Date().toISOString()
      );
      window.gameId = event.data.gameId;
      if (window.callBackAfterJoinGame) {
        if (window.callBackAfterJoinGame === "joinTable") {
          window.isJoiningLoop = true;
        }
        setTimeout(() => {
          window[callBackAfterJoinGame]();
          window.callBackAfterJoinGame = null;
        }, 1500);
      }
    } else if (event.data.type === "MAUBINH_MONITOR_MUST_LEAVE") {
      debug(
        "%c[MauBinh Monitor] Bị yêu cầu rời bàn bởi hệ thống.",
        "color: red;"
      );
      leaveTable();
    }
  });

  // Handle messages from popup
  chrome.runtime.onMessage.addListener((msg, _, sendResponse) => {
    // debug("action: " + msg.action, "color: orange;");
    switch (msg.action) {
      case "saveSettings":
        saveSettings(msg.data);
        sendResponse({ success: true });
        break;
      case "sendUserKey":
        if (msg.userKey) {
          const success = window.websocket.sendUserKey(msg.userKey);
          sendResponse({ success });
        } else {
          sendResponse({ success: false, error: "No userKey provided" });
        }
        break;
      case "executeContentScript":
        debug("functionName: " + msg.functionName, "color: orange;");

        if (msg.functionName) {
          const actions = {
            joinTable: window.joinTable,
            stopJoinTable: window.stopJoinTable,
            createTable: window.createTable,
            leaveTable: window.leaveTable,
            stopCreateTable: window.stopJoinTable,
          };

          if (window.isPlaying) {
            debug(
              "%c[MauBinh Monitor] Người chơi đang chơi. Không thực hiện các tác vụ.",
              "color: red;"
            );
            sendResponse({ status: "Player is playing" });
            return true;
          }
          if (!window.userKey) {
            sendResponse({ status: "No userKey provided" });
            return true;
          }

          if (actions[msg.functionName]) {
            if (!window.gameId) {
              debug(
                "%c[MauBinh Monitor] Không có gameId. Vui lòng đăng nhập.",
                "color: red;"
              );
              sendResponse({ status: "No gameId provided!. Auto Join game" });
              joinGame(msg.functionName);
              return true;
            }
            if (msg.functionName === "leaveTable" || msg.functionName === "stopCreateTable") {
              window.stopJoinTable();
              if (msg.functionName === "leaveTable") {
                window.leaveTable();
              }
            }

            if (msg.functionName === "joinTable" && window.isJoiningLoop) {
              debug(
                "%c[MauBinh Monitor] Quá trình vào bàn đang chạy.",
                "color: orange;"
              );
              return;
            }

            if (msg.functionName === "createTable" && window.isCreatingLoop) {
              debug(
                "%c[MauBinh Monitor] Quá trình vào bàn đang chạy.",
                "color: orange;"
              );
              return;
            }
            if (msg.functionName === "joinTable") {
              window.isJoiningLoop = true;
            }
            if (actions[msg.functionName]) {
              actions[msg.functionName]();
            }
            sendResponse({ status: `${msg.functionName} executed` });
          } else {
            sendResponse({ status: `${msg.functionName} not found` });
          }
        } else {
          sendResponse({ success: false, error: "Missing functionName" });
        }
        break;
      case "checkWebSocketStatus":
        sendResponse({ connected: window.websocket.checkStatus() });
        break;
      default:
        sendResponse({ success: false, error: "Unknown action" });
    }
    return true;
  });
})();
