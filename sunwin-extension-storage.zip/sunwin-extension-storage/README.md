# PHOM BOT - Hệ Thống Bot Chơi Phỏm Tự Động

## 📋 Tổng Quan

Bot Phỏm là một hệ thống AI tự động chơi game Phỏm với chiến lược thông minh, phân tích bài chuẩn xác và ra quyết định tối ưu.

## 🏗️ Kiến Trúc Hệ Thống

Hệ thống gồm 3 components chính:

```
┌─────────────────────────────────────────────────────────┐
│                     GAME SUNWIN                         │
│                  (WebSocket Messages)                   │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│                   inject.js                             │
│  - Inject vào game để intercept messages                │
│  - Track game state (bài của mình, đối thủ, lượt chơi)  │
│  - Gửi MAUBINH_MONITOR events                              │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│               phom-analyzer.js                          │
│  - Nhận raw messages từ inject.js                       │
│  - Phân tích game state & tính toán                     │
│  - Đề xuất recommended moves                            │
│  - Gửi analyzed data qua PHOM_ANALYZER_EVENT            │
└────────────────────┬────────────────────────────────────┘
                     │
                     ▼
┌─────────────────────────────────────────────────────────┐
│                 phom-bot.js                             │
│  - Nhận analyzed data từ analyzer                       │
│  - Ra quyết định cuối cùng (priority-based)             │
│  - Thực hiện actions (click buttons, select cards)      │
│  - Human-like behavior (random delays)                  │
└─────────────────────────────────────────────────────────┘
```

## 🔄 Luồng Xử Lý Chi Tiết

### 1. Game Start Flow

```
inject.js: Phát hiện game bắt đầu
    ↓
    Gửi MAUBINH_MONITOR_INIT
    ↓
phom-analyzer.js: onGameStart()
    ↓
    Reset game state
    ↓
    Gửi PHOM_ANALYZER_EVENT: GAME_START
    ↓
phom-bot.js: handleAnalyzerEvent('GAME_START')
    ↓
    Reset bot state (cards, history, probabilities)
```

### 2. Receive Cards Flow

```
inject.js: Phát hiện nhận bài
    ↓
    Gửi MAUBINH_MONITOR_MY_CARDS {cards: [0,1,2,...]}
    ↓
phom-analyzer.js: onReceiveMyCards()
    ↓
    Lưu cards vào gameState.myCards
    ↓
    Phân tích bài khởi tạo:
    - Tìm sequences (dãy 3+ lá liên tiếp cùng chất)
    - Tìm sets (3+ lá cùng giá trị)
    - Tính hand strength
    ↓
    Gửi PHOM_ANALYZER_EVENT: MY_CARDS_RECEIVED
    {
      cards: [...],
      analysis: {
        sequences: [...],
        sets: [...],
        strength: 85
      }
    }
    ↓
phom-bot.js: handleAnalyzerEvent('MY_CARDS_RECEIVED')
    ↓
    Cập nhật myCards
    ↓
    Điều chỉnh strategy dựa trên hand strength:
    - strength > 70 → aggressive
    - strength < 40 → defensive
    - else → balanced
```

### 3. My Turn Flow (LUỒNG CHÍNH)

```
inject.js: Phát hiện đến lượt mình
    ↓
    Gửi MAUBINH_MONITOR_MY_TURN
    ↓
phom-analyzer.js: onMyTurn()
    ↓
    Phân tích tình huống hiện tại:
    - Game phase (early/mid/late)
    - My advantage
    - Opponent threat
    ↓
    Generate recommended moves (chỉ discard moves)
    - Đánh giá từng lá bài trong tay
    - Tính điểm cho mỗi lá:
      * Trash card bonus (+100 nếu rác hoàn toàn)
      * Phom preservation penalty (-200 nếu phá phỏm)
      * Combo breaking penalty (-50 to -60)
      * Edge card bonus (+30 cho A,K)
    - Sắp xếp theo score giảm dần
    ↓
    Gửi PHOM_ANALYZER_EVENT: MY_TURN
    {
      situation: {...},
      recommendedMoves: [
        {type: 'discard', cards: [5], score: 120},
        {type: 'discard', cards: [12], score: 80},
        ...
      ]
    }
    ↓
phom-bot.js: handleAnalyzerEvent('MY_TURN')
    ↓
    makeOptimalMoveWithAnalysis(analysisData)
    ↓
    Tính delay ngẫu nhiên (2-5 giây) để giống người thật
    ↓
    performTurnSequence(analysisData)
```

### 4. Turn Sequence (PRIORITY-BASED ACTIONS)

Bot thực hiện actions theo **thứ tự ưu tiên**:

```
performTurnSequence():
    ↓
    Check available buttons trong UI
    ↓
    executeHighestPriorityAction():

    ┌─── PRIORITY 1: btn_baoU (Báo Ù) ───────────────┐
    │   - Instant win - kết thúc game ngay           │
    │   - Click và return                             │
    └─────────────────────────────────────────────────┘
              │ (nếu không có)
              ▼
    ┌─── PRIORITY 2: btn_guiBai (Gửi bài) ──────────┐
    │   - End game with advantage                    │
    │   - Click và return                            │
    └────────────────────────────────────────────────┘
              │ (nếu không có)
              ▼
    ┌─── PRIORITY 3: btn_haPhom (Hạ phỏm) ──────────┐
    │   - Play combinations                          │
    │   - Click NHƯNG KHÔNG kết thúc turn            │
    │   - Continue để check draw/discard             │
    └────────────────────────────────────────────────┘
              │
              ▼
    ┌─── PRIORITY 4: Draw Action ────────────────────┐
    │   Chọn 1 trong 2:                              │
    │   - btn_anBai2 (Ăn bài trên bàn)              │
    │   - btn_rutBai2 (Rút bài từ deck)             │
    │                                                 │
    │   Quyết định dựa trên:                         │
    │   - Current strategy (aggressive/defensive)    │
    │   - Hand analysis                              │
    │   - Game phase                                 │
    │   - Random factor (human-like)                 │
    └────────────────────────────────────────────────┘
              │
              ▼
    ┌─── POST-DRAW: Check lại high-priority ────────┐
    │   Sau khi draw thêm 1 lá, check lại:          │
    │   - Có thể Ù không?                            │
    │   - Có thể Gửi bài không?                      │
    │   - Có thể Hạ phỏm không?                      │
    └────────────────────────────────────────────────┘
              │
              ▼
    ┌─── PRIORITY 5: btn_xepBai (Xếp bài) ──────────┐
    │   - Auto arrange cards                         │
    │   - Click và đợi 2 giây                        │
    └────────────────────────────────────────────────┘
              │
              ▼
    ┌─── PRIORITY 6: btn_danhBai (Đánh bài) ────────┐
    │   - Discard 1 lá để kết thúc turn             │
    │   - Chọn lá dựa trên analyzer recommendations  │
    └────────────────────────────────────────────────┘
```

### 5. Optimal Discard Logic (THUẬT TOÁN CHỌN BÀI)

```
performOptimalDiscardSequence():
    ↓
    Lấy recommended moves từ analyzer
    ↓
    Với mỗi lá bài trong tay:
    ↓
    calculateCardSafetyScore(card):
        │
        ├─ PRIORITY 1: Phân tích lá rác
        │  analyzeTrashCard():
        │    - Đếm số lá liên quan (cùng chất gần nhau, cùng giá trị)
        │    - relatedCards = 0 → +100 điểm (rác hoàn toàn)
        │    - relatedCards = 1 → +50 điểm (ít liên quan)
        │    - relatedCards >= 2 → -30 điểm (có thể tạo combo)
        │
        ├─ PRIORITY 2: Bảo vệ phỏm đã có
        │  calculatePhomBreakingPenalty():
        │    - isPartOfExistingPhom() → -1000 điểm
        │    - TUYỆT ĐỐI không đánh lá trong phỏm
        │
        ├─ PRIORITY 3: Tránh phá combo tiềm năng
        │  calculateComboBreakingPenalty():
        │    - Có 2 lá liên tiếp (gần thành sequence) → -50
        │    - Có 2 lá cùng giá trị (gần thành set) → -60
        │
        ├─ Factor 4: Lá biên an toàn
        │  calculateEdgeCardBonus():
        │    - A, K → +30 (chỉ 1 hướng tạo sequence)
        │    - 2, Q → +20
        │    - 3, J → +10
        │    - 5-9 → -5 (2 hướng, nguy hiểm)
        │
        ├─ Factor 5: Bài chết (dead cards)
        │  calculateDeadCardBonus():
        │    - Đếm lá liên quan đã được đánh
        │    - Mỗi lá sequence neighbor đã chết → +15
        │    - Mỗi lá set neighbor đã chết → +10
        │
        ├─ Factor 6: Pattern đối thủ
        │  calculateOpponentPatternRisk():
        │    - Đối thủ đánh nhiều lá cùng chất → -20
        │    - Đối thủ đánh lá liền kề → -30
        │
        ├─ Factor 7: Lá cô lập
        │  calculateIsolationBonus():
        │    - Hoàn toàn cô lập → +50
        │    - Ít liên quan → +30
        │    - Nhiều khả năng combo → -20
        │
        └─ Factor 8: Hand strength adjustment
           - Late game + edge card → +10
           - Defensive strategy → tăng isolation bonus
    ↓
    Sắp xếp lá theo totalScore (cao → thấp)
    ↓
    Chọn lá có score cao nhất
    ↓
    performOptimalDiscard():
        - selectCard(cardNumber) → Click vào lá bài
        - Đợi 1 giây
        - clickGameButton('btn_danhBai') → Click nút đánh bài
```

### 6. Opponent Cards Played Flow

```
inject.js: Phát hiện đối thủ đánh bài
    ↓
    Gửi MAUBINH_MONITOR_OPPONENT_PLAYED_CARDS
    ↓
phom-analyzer.js: onOpponentCardsPlayed()
    ↓
    Phân tích pattern đối thủ:
    - 1 lá → discard (aggressiveness: 3)
    - 3+ lá sequence → aggressive (aggressiveness: 7)
    - 3+ lá set → very aggressive (aggressiveness: 8)
    ↓
    Tính threat level (0-10)
    ↓
    Gửi PHOM_ANALYZER_EVENT: OPPONENT_CARDS_PLAYED
    ↓
phom-bot.js: handleAnalyzerEvent('OPPONENT_CARDS_PLAYED')
    ↓
    Cập nhật opponentPlayedCards
    ↓
    updateOpponentStrategy():
    - Lưu pattern vào database
    - Nếu threat > 8 → chuyển sang defensive strategy
```

## ⚠️ VẤN ĐỀ DUPLICATE LOGIC

### Duplicate 1: Trash Card Analysis

**Vị trí:**

- `phom-bot.js`: `analyzeTrashCard()` (line 598)
- `phom-analyzer.js`: `checkTrashCard()` (line 552)

**Mô tả:**
Cả 2 methods đều phân tích lá rác bằng cách:

- Đếm số lá liên quan (cùng chất gần nhau, cùng giá trị)
- Trả về score dựa trên số lượng related cards

**Giải pháp:**

- Giữ logic ở `phom-analyzer.js` (analyzer phân tích)
- `phom-bot.js` dùng kết quả từ analyzer, không tính lại

### Duplicate 2: Phom Detection

**Vị trí:**

- `phom-bot.js`: `isPartOfExistingPhom()` (line 685)
- `phom-analyzer.js`: `isPartOfExistingPhom()` (line 581)

**Mô tả:**
Code HOÀN TOÀN GIỐNG NHAU:

- Kiểm tra sequence (3+ lá liên tiếp cùng chất)
- Kiểm tra set (3+ lá cùng giá trị)

**Giải pháp:**

- Chuyển logic về `phom-analyzer.js`
- Bot chỉ nhận kết quả đã phân tích

### Duplicate 3: Combo Breaking Detection

**Vị trí:**

- `phom-bot.js`: `calculateComboBreakingPenalty()` (line 745)
- `phom-analyzer.js`: `checkComboBreaking()` (line 627)

**Mô tả:**
Cả 2 đều kiểm tra:

- Sequence tiềm năng (2 lá liên tiếp)
- Set tiềm năng (2 lá cùng giá trị)
- Trả về penalty points

**Giải pháp:**

- Analyzer tính toán và gửi trong recommended moves
- Bot không cần tính lại

## 🔧 LOGIC KHÔNG CẦN THIẾT

### 1. Bot's Self-Analysis Methods (UNUSED)

Bot có nhiều methods phân tích nhưng KHÔNG dùng vì analyzer đã làm:

```javascript
// phom-bot.js - KHÔNG CẦN THIẾT
-calculateOptimalDiscard() - // Line 1109: Analyzer đã recommend
  generatePossibleMoves() - // Line 1579: Analyzer đã generate
  generateDiscardMoves() - // Line 1606: Analyzer đã generate
  analyzePossibleMoves() - // Line 1402: Analyzer đã analyze
  findAllCombinations(); // Line 1435: Analyzer đã find
```

**Lý do:** Analyzer đã gửi `recommendedMoves` với đầy đủ thông tin, bot chỉ cần execute.

### 2. Duplicate Card Probability System

Cả bot và analyzer đều maintain:

- `cardProbabilities` map
- `updateCardProbabilities()` method

**Giải pháp:** Chỉ analyzer cần track probabilities để recommend moves.

### 3. Redundant Game State Tracking

```javascript
// phom-bot.js
this.myCards = new Set();
this.myPlayedCards = new Set();
this.opponentPlayedCards = new Set();

// phom-analyzer.js
this.gameState = {
  myCards: new Set(),
  tableCards: [],
  ...
};
```

**Giải pháp:** Analyzer là single source of truth cho game state.

## 📊 Data Flow Summary

```
ANALYZER (phân tích):
✓ Track game state
✓ Analyze hand strength
✓ Calculate card safety scores
✓ Generate recommended moves
✓ Analyze opponent patterns
✓ Determine game phase
✓ Calculate probabilities

BOT (hành động):
✓ Execute highest priority action
✓ Click buttons (Ù, Gửi bài, Hạ phỏm)
✓ Choose between Ăn bài/Rút bài
✓ Select optimal card to discard
✓ Human-like behavior (delays)
✓ Fallback handling
```

## 🎯 Recommended Refactoring

### Phase 1: Remove Duplicates

1. Xóa `analyzeTrashCard()` trong bot → dùng analyzer's result
2. Xóa `isPartOfExistingPhom()` trong bot → dùng analyzer's result
3. Xóa `calculateComboBreakingPenalty()` trong bot → analyzer include trong score

### Phase 2: Clean Unused Code

1. Xóa bot's analysis methods (generatePossibleMoves, etc.)
2. Chuyển probability tracking về analyzer only
3. Simplify bot's game state (chỉ giữ minimal info cần cho actions)

### Phase 3: Optimize Communication

1. Analyzer gửi complete decision data (không chỉ recommendations)
2. Bot chỉ focus vào UI interactions
3. Tách riêng utility functions (parseCard, getCardName) ra shared module

## 🚀 Cách Bot Hoạt Động (Tóm Tắt)

1. **Analyzer** phân tích game → gửi "recommendedMoves" với scores đã tính
2. **Bot** nhận moves → chọn move tốt nhất → execute bằng cách:
   - Check buttons có available không
   - Click theo priority (Ù > Gửi > Hạ phỏm > Draw > Discard)
   - Add random delays để giống người thật
3. **Human-like behavior**: Random delays 2-5s, random decisions khi có multiple options
4. **Strategy adaptation**: Tự động chuyển aggressive/defensive dựa trên hand strength & opponent threat

## 📝 Kết Luận

Bot hiện tại **HOẠT ĐỘNG TốT** nhưng có **NHIỀU CODE TRÙNG LẶP** không cần thiết:

- Analyzer và Bot cùng phân tích trash cards
- Analyzer và Bot cùng detect phỏm
- Bot có nhiều analysis methods không dùng

**Nguyên tắc:** Analyzer phân tích, Bot hành động. Không nên overlap responsibilities.
