document.addEventListener("DOMContentLoaded", () => {

  let currentAction = null;
  // DOM elements
  const elements = {
    systemKeysInput: document.getElementById("systemKeys"),
    joinDelayInput: document.getElementById("joinDelay"),
    checkDelayInput: document.getElementById("checkDelay"),
    selectedTableInput: document.getElementById("selectedTable"),
    saveSettingsButton: document.getElementById("saveSettings"),
    startButton: document.getElementById("start"),
    stopButton: document.getElementById("stop"),
    botToggle: document.getElementById("botModeToggle"),
    actionSelect: document.getElementById("actionSelect"),
    connectionStatus:
      document.getElementById("connectionStatus") ||
      document.createElement("div")
  };

  // Constants
  const LOG_PREFIX = "[MauBinh Monitor]";

  // Helper functions
  const log = (message, data) => {
    console.log(LOG_PREFIX, message, data || "");
  };

  const loadFromStorage = (keys, callback) => {
    chrome.storage.local.get(keys, callback);
  };

  const saveToStorage = (data, callback) => {
    chrome.storage.local.set(data, callback);
  }

  const showAlert = (message) => {
    alert(message);
  };

  // Send message to background script
  const sendMessageToContent = (message, callback) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length === 0) {
        log("No active tab found");
        return;
      }
      tabs.forEach((tab) => {
        if (tab.url.includes("sun.win") || tab.url.includes("sunwin")) {
          chrome.tabs.sendMessage(tab.id, message, (response) => {
            if (chrome.runtime.lastError) {
              log(
                "Error sending message to content script:",
                chrome.runtime.lastError
              );
              if (callback)
                callback({ success: false, error: chrome.runtime.lastError });
              return;
            }
            if (callback) callback(response);
          });
        }
      });
    });
  };

  // Execute content script via background
  const executeContentScript = (functionName) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (tabs.length === 0) {
        log("No active tab found");
        return;
      }

      sendMessageToContent({
        action: "executeContentScript",
        functionName: functionName,
        tabId: tabs[0].id,
      });
    });
  };

  // Save settings via background script
  const saveSettings = () => {
    const joinDelay = parseInt(elements.joinDelayInput.value) || 1000;
    const checkDelay = parseInt(elements.checkDelayInput.value) || 1000;
    const selectedTable = elements.selectedTableInput.value;
    const rawSystemKeys = elements.systemKeysInput.value.trim() || "";
    const botMode = elements.botToggle.checked;

    const systemKeys = rawSystemKeys ? rawSystemKeys
      .split(",")
      .map((key) => key.trim())
      .filter((key) => key) : [];

    saveToStorage({ systemKeys, joinDelay, checkDelay, selectedTable, botMode });

    sendMessageToContent(
      {
        action: "saveSettings",
        data: { joinDelay, checkDelay, selectedTable, systemKeys, botMode },
      },
      (response) => {
        if (response && response.success) {
          showAlert("Settings saved!");
        } else {
          showAlert("Error saving settings. Please try again.");
        }
      }
    );
  };

  // Check WebSocket connection status
  const checkConnectionStatus = () => {
    sendMessageToContent({ action: "checkWebSocketStatus" }, (response) => {
      if (response && response.connected) {
        elements.connectionStatus.textContent = "Connected to WebSocket";
        elements.connectionStatus.style.color = "green";
      } else {
        elements.connectionStatus.textContent = "Disconnected from WebSocket";
        elements.connectionStatus.style.color = "red";
      }
    });
  };

  // Listen for messages from background script
  chrome.runtime.onMessage.addListener((message) => {
    log("Received message from background:", message);

    if (message.action === "websocketConnected") {
      elements.connectionStatus.textContent = "Connected to WebSocket";
      elements.connectionStatus.style.color = "green";
    } else if (message.action === "settingsSaved") {
      // Update UI if settings were saved from another source (e.g., WebSocket)
      const { systemKeys, joinDelay, checkDelay, selectedTable } = message.data;
      if (systemKeys) elements.systemKeysInput.value = systemKeys.join(",");
      if (joinDelay) elements.joinDelayInput.value = joinDelay;
      if (checkDelay) elements.checkDelayInput.value = checkDelay;
      if (selectedTable) elements.selectedTableInput.value = selectedTable;
      if (botMode) elements.botToggle.checked = botMode;
    }
  });

  // Load saved data
  loadFromStorage(
    ["systemKeys", "joinDelay", "checkDelay", "selectedTable", "botMode"],
    ({ systemKeys, joinDelay, checkDelay, selectedTable, botMode }) => {
      if (systemKeys) elements.systemKeysInput.value = systemKeys.join(",");
      if (joinDelay) elements.joinDelayInput.value = joinDelay;
      if (checkDelay) elements.checkDelayInput.value = checkDelay;
      if (selectedTable) elements.selectedTableInput.value = selectedTable;
      if (botMode) elements.botToggle.checked = botMode;
      console.log(elements.botToggle.checked, botMode);

    }
  );

  // Add connection status element if it doesn't exist
  if (!document.getElementById("connectionStatus")) {
    elements.connectionStatus.id = "connectionStatus";
    elements.connectionStatus.style.marginTop = "10px";
    elements.connectionStatus.style.textAlign = "center";
    document.body.appendChild(elements.connectionStatus);
  }

  // Check connection status when popup opens
  checkConnectionStatus();
  // Check connection status every 5 seconds
  setInterval(checkConnectionStatus, 5000);

  // Event listeners
  elements.saveSettingsButton.addEventListener("click", saveSettings);

  // Game control buttons
  elements.startButton.addEventListener("click", () => {
    isJoining = true;
    const selectedAction = elements.actionSelect.value;
    executeContentScript(selectedAction);
    currentAction = selectedAction;
    console.log("Trigger action", currentAction);
  });

  elements.stopButton.addEventListener("click", () => {
    isJoining = false;
    if (currentAction === "joinTable") {
      executeContentScript("stopJoinTable");
    } else if (currentAction === "createTableBot") {
      executeContentScript("leaveTable");
    } else {
      executeContentScript("leaveTable");
    }
  });
});
